import sys
sys.stdin = open('treasure.txt', 'r')

